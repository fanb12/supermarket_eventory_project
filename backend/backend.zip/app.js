console.log("object");
// import the express module
const express = require("express");

// import the dotenv module and call the config method to load the enviroment variable
require("dotenv").config();

// import the sanitizer module
const sanitize = require("sanitize");
// import the cors module
const cors = require("cors");
const app = express();
// Set up the Cors options to allow requests from our front-end
// app.use(cors());
app.use(
  cors({
    origin: "http://localhost:5173",
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true,
  })
);
//app.options('*', cors());

// create a variable to hold our port number
const port = process.env.PORT;

// import the router9
const router = require("./routes");

// create a webserver

// add the CORS middleware
//app.use(cors(corsOptions));
app.get("/example", (req, res) => {
  // Set headers before sending the response
  res.setHeader("Content-Type", "application/json");
  res.setHeader("X-Custom-Header", "value");

  // Send the response
  res.send({ message: "Hello, world!" });

  // Avoid modifying headers after the response is sent
  // res.setHeader('Another-Header', 'value'); // This will cause the error
});
// Add the express.json middleware to the application
app.use(express.json());

// Add the sanitizer to the express middleware
app.use(sanitize.middleware);

// Add the routes to the application as middleware9
app.use(router);

app.listen(port, () => {
  console.log(`Server Running on Port: ${port}`);
});

module.exports = app;
